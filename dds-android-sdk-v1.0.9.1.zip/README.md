术语：
* dds : dui dialog service


文件组成：
* lib-dds-{version}-release.aar : dds的android sdk
* ddsDemo.zip : dds android sdk的demo工程

DEMO工程：
* app:使用webview加载内置html5 UI的方式显示对话内容
* nativedemo:使用nativeUI的方式显示对话内容


sdk文档:
* 链接地址 : https://www.dui.ai/docs/operation/#/ct_andriodSDK
